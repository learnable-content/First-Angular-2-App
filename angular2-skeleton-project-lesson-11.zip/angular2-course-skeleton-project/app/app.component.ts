import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    template: '<h1>Skeleton Project</h1>'
})
export class AppComponent { }